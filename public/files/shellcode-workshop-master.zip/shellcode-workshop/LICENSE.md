# License Grant
Each participant is granted a non-exclusive, royalty-free, perpetual license to use, modify, and compile the provided source code for their own work and to make it available for internal use within their employing company. Redistribution, sublicensing, resale, or making the source code available to any third party outside that company is prohibited.

# Disclaimer
The source code is provided “as is,” without warranty of any kind, express or implied. The licensor is not liable for any damages arising from use of the code.
