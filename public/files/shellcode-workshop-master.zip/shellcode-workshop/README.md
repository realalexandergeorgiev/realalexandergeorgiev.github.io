# A Rustacean Introduction to Shellcoding


## Getting ready

Run these powershell commands!

```powershell
mkdir "$env:USERPROFILE\Tools"
winget install Microsoft.WinDbg
winget install pe-bear

wget https://download.sysinternals.com/files/ProcessExplorer.zip -o "$env:USERPROFILE\Downloads\ProcessExplorer.zip"
Expand-Archive -Path "$env:USERPROFILE\Downloads\ProcessExplorer.zip" -DestinationPath "$env:USERPROFILE\Tools"

wget https://download.sysinternals.com/files/ProcessMonitor.zip -o "$env:USERPROFILE\Downloads\ProcessMonitor.zip"
Expand-Archive -Path "$env:USERPROFILE\Downloads\ProcessMonitor.zip" -DestinationPath "$env:USERPROFILE\Tools"

wget http://www.rohitab.com/download/api-monitor-v2r13-x86-x64.zip -o "$env:USERPROFILE\Downloads\api-monitor.zip"
Expand-Archive -Path "$env:USERPROFILE\Downloads\api-monitor.zip" -DestinationPath "$env:USERPROFILE\Tools"


wget https://github.com/changeofpace/PE-Header-Dump-Utilities/releases/download/v1.0/PEHeaderDumpUtilities.dp64 -o "$env:USERPROFILE\Downloads\PEHeaderDumpUtilities.dp64"

```

# x64dbg Image Export Directory Header


Save that to VM, we will need that later.


```
struct IMAGE_EXPORT_DIRECTORY {
    unsigned int Characteristics;
    unsigned int TimeDateStamp;
    unsigned short MajorVersion;
    unsigned short MinorVersion;
    unsigned int Name;
    unsigned int Base;
    unsigned int NumberOfFunctions;
    unsigned int NumberOfNames;
    unsigned int AddressOfFunctions;
    unsigned int AddressOfNames;
    unsigned int AddressOfNameOrdinals;
};
```

