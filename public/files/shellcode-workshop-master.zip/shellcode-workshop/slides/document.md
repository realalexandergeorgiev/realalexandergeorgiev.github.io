---
title: "A Rustacean Introduction to Shellcoding"
subtitle: Workshop @ BSides FFM
author: ["Ben Stuart <ben.stuart@stuart-security.de>"]
date: "2025-08-28"
subject: "Workshop"
keywords: [Markdown, Example]
lang: "en"
aspectratio: 169
section-titles: false
slide-level: 2
shift-heading-level: 0
code-block-font-size: \footnotesize
---


# Whoami

- Using Rust since 1.0 (2015)
- Computer Scientist by heart
- By Trade: Pentester & IT Security Consultant
- Security Cert Enthusiast


# Who are you?!

Introduce yourself!

- What is your experience with Rust?
- What is your experience with shellcodes?
- What do you know about Windows Internals?


# What to Expect {.allowframebreaks}


The workshop will be mix out of follow along, some theory and one part Do-It-Yourself.

:::::: {.columns}
::: {.column width="50%"}

- A quick introduction to Rust
    - Language Feature and Syntax
    - Ecosystem 
    - Play with Code
- Working with the Windows (PE)

:::
::: {.column width="50%"}

- Prior-Art (Stardust)
    - Integrate Windows API 
    - Memory Allocation
    - Memory Permission
    - Communication
    - Integrating Assembly
- Evasion Techniques 

:::
::::::

Furthermore:

1. Ask Question and interrupt me if needed!
2. We will take a couple of breaks! 


\framebreak

We will need to use some "Evasion" techniques to make the shellcode work.

- Retrieval and inspection of the PEB 
- IAT Obfuscation
    - Custom GetModuleHandle
    - Custom GetProcAddr
- Shellcode Execution via ProcessInjection

Furthermore, we will cover a variant of Hells Gate (HellsHall). You will implement the required function, to make the indirect syscall work.

# Getting the Material

Download the Workshop Material

```bash
git clone https://bsides.stuart-security.de/bsides-ffm/shellcode-workshop.git
```

The Repo contains:

- Slides
- Shellcode Template
- Rust Code Snippets

# Setup

\Huge\centering Let us setup the VM!




# Rust 101 {.allowframebreaks}


Rust is an expression based language with type inference and data orientated.


In Short:

- Define your data via `struct` or `enums`
- Define data behaviour via `function` and `traits`

That's it!

\framebreak

```rust
fn bar() -> u32 {
    a // No return required 
}
```

But here a `return` is required

```rust
fn foo() -> u32 {
    if true {
        // Early returns require a return
        return 42
    }
    24
}

```

`if` and `else` or `match` can also be expression.


```rust
fn baz() {
    let a = if true { 42 } else { 24 };

    let b = match a {
        42 => "42",
        24 => "24",
        _ => "fallthrough",
    };
}

```


Pattern Matching & Destructering is also supported.


```rust
struct A {
    a: u32,
    b: String,
}

fn bak(a: A) {
    let A { a, b } = a; 
    match b {
        "xxx" => println!("Case {}", b),
        "asda" @ i => println!("Variable binding {i}"),
        // No exception but panics
        _ => panic!("We will crash"), 
    }
}
```


Some String Types are confusing. Rust has different kinds of strings:

| DataType | Purpose |
| ----   |  ---- |
| String | Heap Allocated UTF-8 String |
| OsString | Heap Allocated OS Compatible String | 
| CString | Heap Allocated C compatible String |
| &str   | Reference to UTF-8 String Buffer | 
| &OsStr | OS Compatbile Reference to String Buffer |
| &CStr | C compatible String Reference | 

A &str can also be a slice like:

```rust
let b: &str = "Hello World!";
let a: &[u8] = b.as_bytes();
```

Every `&str` can a be a `&[u8]`, but not every `&[u8]` is a valid `&str`.


\framebreak

Some examples of datatypes

```rust
struct NAME {
    FIELD: TYPE
}

```

Rust supports the algebraric datatypes

```rust
enum A {
    A,
    B(u32),
    C { a: u32, b: String },
}
```

In C this would be called a "Tagged Union". Unions are for FFI also supported, but not coverered ([read more about it here](https://doc.rust-lang.org/reference/items/unions.html)).



\framebreak

Rust supports Interfaces via `trait`.


```rust

trait Write {
    fn write(&mut self, data: &str);
}
```

Dynamic dispatching is supported through Downcasting to achieve Type Erasure, e.g
```rust
struct A;
impl Write for A {
    fn write(&self, data: &str) { println!("{}", data); }
}
let mut a: Box<dyn Write> = Box::new(A)
a.write("Hello World");
```

Static dispatch is the default

```rust
let mut a = A;
a.write("Hello World");
```
and can be used by functions

```rust
fn call_me(writer: impl Write) {
    writer.write("ABC");
}
```


Traits can only be implemented for types within the same crate, e.g.

- Trait A of crate A, can be used by crate B.
- crate C can not implement Trait for types of crate B.

This is solved via the NewType-Pattern.


Rust has also a "new type" pattern:

```rust
// Type of crate B
struct OldName { /* ... */}

struct NewName(OldName);

```


\framebreak



Integers are simple. The prefix `u` for indicates the signedness followed by the number for the width, e.g.

```rust
let a: u32 = 32;
let a: i32 = 32;
// OR

let a = 32u64;
let d = 0x0000_FFFFu32; // hex
let b = 0b000_1111u16; // binary
```

128-Bit Integers are supported!

\framebreak

Rust has lifetimes for references.

```rust
fn baz<'a>(a: &'a [u8]) -> &'a [u8] {
    &a[..10]
}

```

\framebreak

Rust also support procedural and "regular" Macros.

An Example for procedural macro usage would be:

```rust
#[derive(Debug, serde::Serialize, serde::Deserialize)]
#[serde(rename_all="kebab-case")]
struct A {
    a_number: u32
}
```

or 

```rust
println!("Hello, World");
```



Most notorious feature, the Borrow Checker. But fear not! Simply put, it is a compile-time Read-Write-Lock.


| Annotation | Achieved Effect   | 
| ----      | -----             |
| &mut T     | Mutable Reference, One Writer, No Reader | 
| &T     | Immutable Reference, No Writer, Multiple Reader | 
| T     | Immutable Owner of Memory | 
| mut T  | Mutable Owner of Memory |


But remember, if you hold a mutable reference, you can always created immutable references from it!



Apart from the Borrow Checker, also Thread Safety is achieved through `Send` & `Sync` traits.

- Send: Memory can be Send over Thread bounds
- Sync: Memory is synchronized over Thread bounds 



# Rust Ecosystem


The package and toolchain manager is included:

- Cargo, for package and dependency management ([Crate Registry](https://crates.io/)).
    - Cargo can be extended with subcommands, e.g. `cargo make`
- rustup, for Rust toolchain management.


Let's test cargo by creating a empty project `ready-to-test`

```
cargo new --bin ready-to-test
```

---

Some common libraries for specific use cases:

- ring: Crypto
- tokio: Async Runtime and IO Stack
- hyper: HTTP
    - All major full-stack http servers are build on hyper
- serde: Serialization
- bincode: Binary Encoding
- sqlx: Database clients
- bindgen: Automatically create Rust bindings to C FFI
- cbindgen: Automcatically Expose Rust to C FFI

Common patterns for specific libraries:

- Low Level libraries have the suffix "-sys".
- Macro crates have the suffix "-derive"


# Break


\begin{center}
\Huge{Short break: 10 minutes}
\end{center}


# Windows Environment {.allowframebreaks .fragile}


- Every running process has a Process Environment Block (PEB). [NtDocs PEB](https://ntdoc.m417z.com/peb), [PEB Microsoft Documentation](https://learn.microsoft.com/en-us/windows/win32/api/winternl/ns-winternl-peb)
- We want to investigate the LDR datastructure [NtDocs LDR](https://ntdoc.m417z.com/peb_ldr_data), [LDR Microsoft Documentation](https://learn.microsoft.com/en-us/windows/win32/api/winternl/ns-winternl-peb_ldr_data)


We want the retrieve loaded module and from there import and retrieve needed functions.

# Finding modules and functions


![](WalkingThePEB.png){width=80%, height=60%}


The Image Export Directory contains virtual addresses and all function exported by the dll.


# Working with the Export Directory

```rust
pub struct IMAGE_EXPORT_DIRECTORY {
    pub Characteristics: u32,
    pub TimeDateStamp: u32,
    pub MajorVersion: u16,
    pub MinorVersion: u16,
    pub Name: u32,
    pub Base: u32,
    pub NumberOfFunctions: u32,     // number of function
    pub NumberOfNames: u32,         // number of function names
    pub AddressOfFunctions: u32,    // Virtual Address of the function. Can be indexed by the Ordinal number
    pub AddressOfNames: u32,        // Array of virtual address to function names
    pub AddressOfNameOrdinals: u32, // Contains the Ordinal numbers
}
```


# Stardust {.allowframebreaks}

Stardust uses a central global `Instance` data structure to hold all API pointers and metadata.

Typical structure

```rust
struct Instance {
    base: *mut c_void,
    base_len: usize,
    ntdll: Ntdll,
    kernel32: Kernel32,
    // etc.
}
```


\framebreak


Their different designs possible.

- Stacked based
- Heap based

We cover the heap based one. This is the most extendable and allows more advanced use cases.
The heap based design also allows recovery of previous stardust instances.


\framebreak

Requirements and Challenges:

- Linker Script for a specific programm layout
- Must find the start and end of the shellcode
- Initialization of heap allocators and other structures 
- Finding the ntdll, kernel32, Ws2_32 DLLs functions

# Task: Stardust

Let's talk and look at the project stub structure!


# Task: Tackling allocation


Take a look at `allocator.rs` and complete the trait implementation of `GlobalAlloc` for  `NtAlloc`.


# Task: Custom GetProcAddr

Complete the following functions:

- `get_proc_addr` to implement a replacment for the Windows Native `GetProcAddr`.
- `get_module_handle` to implement a replacment for the Windows Native `GetModuleHandle`.


# Task: Taking a indirect tour through hell

Improve the shellcode and write a syscall dumper. The code should handle error cases.
Use the debugger to determine the required bytes to identify syscalls

Use the provided function signature

```Rust
pub fn syscall_number_and_addr(func_ptr: *mut c_void) -> Result<(u32, usize), ()> {
}
```


> Hint: Syscalls typically are 16 Bit


Use a macro to simplify the usage of `make_syscall`

# Task: Implement the reverse shell

Implement a simple reverse shell in the file `rev-shell.rs`


# Task: Adding obfuscation

Optionally: Add obfuscation to the initial shellcode loader!

Take a look at `loader/build.rs`


# Task: Implement the stager! {.allowframebreaks}

Use the provided API to implement the stager for the shellcode!


You will need following APIs:

- WSAStartup
- WSASocket
- WSAConnect
- WSARecv
- NtWriteVirtualMemory
- NtAllocateVirtualMemory
- NtProtectVirtualMemory
- NtCreateThreadEx
- NtWaitForSingleObject


## Optional Task

1. Encode the shellcode through the usage of `build.rs`
2. Perform thread injection on another process by using `NtOpenProcess`



# Task: Implement the TCP Handler

Take a look at the handler and implement a TcpListener to serve the second stage of the shellcode.

# Feedback

\centering
\includegraphics[scale=0.5]{./Feedback.png}


Please leave your feedback using the QR code or [by clicking here](https://cloud.stuart-security.de/apps/forms/s/fNidfBMAHWtSEKb6C8QqNmHw)! Thank you!
