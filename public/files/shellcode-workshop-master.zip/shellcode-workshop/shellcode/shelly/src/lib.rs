#![no_std]
#![no_main]

extern crate alloc;

use core::{
    arch::{asm, naked_asm},
    panic::PanicInfo,
};
use shelly_lib::{
    allocator::NtHeapAlloc,
};

pub mod utils;

#[global_allocator]
pub static ALLOCATOR: NtHeapAlloc = NtHeapAlloc::new();

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {
        unsafe {
            asm!("int3");
        }
    }
}

#[unsafe(naked)]
#[unsafe(no_mangle)]
#[unsafe(link_section = ".text.prologue")]
pub unsafe extern "C" fn _start() {
    naked_asm!(
        "push  rsi",
        "mov   rsi, rsp",
        "and   rsp, 0xFFFFFFFFFFFFFFF0",
        "sub rsp, 0x20",
        "call  {init}",
        "mov   rsp, rsi",
        "pop   rsi",
        "ret",
        init = sym init
    );
}

unsafe extern "C" {
    fn init();
}


