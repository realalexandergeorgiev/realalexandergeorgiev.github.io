use core::net::Ipv4Addr;

use windows_sys::Win32::Networking::WinSock::SOCKADDR_IN;

pub fn tcp_socket_addr(ipv4: Ipv4Addr, port: u16) -> SOCKADDR_IN {
    SOCKADDR_IN {
        sin_family: windows_sys::Win32::Networking::WinSock::AF_INET,
        sin_port: port.to_be(),
        sin_addr: windows_sys::Win32::Networking::WinSock::IN_ADDR {
            S_un: windows_sys::Win32::Networking::WinSock::IN_ADDR_0 {
                S_addr: ipv4.to_bits().to_be(),
            },
        },
        sin_zero: [0; 8],
    }
}
