use windows_sys::Win32::Foundation::HANDLE;

pub const STDOUT_HANDLE: HANDLE = -11i32 as u32 as HANDLE;
pub const CURRENT_PROCESS: HANDLE = usize::MAX as HANDLE;
pub const WSA_STARTUP_VERSION: u16 = 0x0202;

unsafe extern "C" {
    static mut _data_offset: usize;
    static mut _epilogue_offset: usize;
}

pub fn data_offset() -> usize {
    let addr = &raw mut _data_offset;
    addr as usize
}
