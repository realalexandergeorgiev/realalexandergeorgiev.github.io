.global make_syscall

.section .text

make_syscall:
    mov [rsp - 0x8],  rsi   # save
    mov [rsp - 0x10], rdi   # save
    mov [rsp - 0x18], r12   # save

    mov eax, ecx            # storing syscall number to eax
    mov r12, rdx            # Saving syscall addr to R12
    mov rcx, r8             # Saving argc to rcx

    mov r10, r9             # Saving fourth argument to r10
    mov  rdx,  [rsp + 0x28] # Setting up arg2
    mov  r8,   [rsp + 0x30] # Setting up arg3
    mov  r9,   [rsp + 0x38] # Setting up arg4

    sub rcx, 0x4            # Reducing argc by 4
    jle skip                # skip if no addtional arguments are passed

    lea rsi,  [rsp + 0x40]  # Src
    lea rdi,  [rsp + 0x28]  # Dst

    rep movsq
skip:

    mov rcx, r12            # Moving the syscall addr to rcx

    mov rsi, [rsp - 0x8]    # restore
    mov rdi, [rsp - 0x10]   # restore
    mov r12, [rsp - 0x18]   # restore

    jmp rcx                 # Do indirect syscall

