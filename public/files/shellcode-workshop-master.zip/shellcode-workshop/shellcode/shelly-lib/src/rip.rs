use core::{arch::asm, ffi::c_void};

#[unsafe(naked)]
#[unsafe(link_section = ".text.prologue")]
unsafe extern "C" fn _rip_start() -> *mut c_void {
    core::arch::naked_asm!(
        "call {ptr_start}",
        "ret",
        ptr_start = sym _rip_ptr_start,
    );
}

#[unsafe(naked)]
#[unsafe(link_section = ".text.prologue")]
unsafe extern "C" fn _rip_ptr_start() -> *mut c_void {
    core::arch::naked_asm!("mov rax, [rsp]", "sub rax, 0x1d", "ret");
}

pub extern "C" fn rip_start() -> *mut c_void {
    let addr: *mut c_void;

    unsafe {
        asm!(
            "call {start}",  // call the assembly function
            "mov {0}, rax",  // move the value in rax to addr
            out(reg) addr,   // output to addr
            start = sym _rip_start
        );
    }

    addr
}

#[unsafe(naked)]
#[unsafe(link_section = ".text.epilogue")]
unsafe extern "C" fn _rip_end() -> *mut c_void {
    core::arch::naked_asm!("call {ptr_end}", "ret", ptr_end = sym _rip_ptr_end)
}

#[unsafe(naked)]
#[unsafe(link_section = ".text.epilogue")]
unsafe extern "C" fn _rip_ptr_end() -> *mut c_void {
    core::arch::naked_asm!(
        "mov rax, [rsp]", // get the return address
        "add rax, 0xB",   // get implant end address
        "ret"             // return to _rip_end
    )
}

#[unsafe(naked)]
#[unsafe(link_section = ".text")]
pub unsafe extern "C" fn rip_end() -> *mut c_void {
    core::arch::naked_asm!(
        "call {end}",
        "ret",
        end = sym _rip_end
    )
}
