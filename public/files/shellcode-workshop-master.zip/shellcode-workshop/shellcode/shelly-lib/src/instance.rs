use core::{
    ffi::c_void,
    ptr::null_mut,
    sync::atomic::{AtomicPtr, Ordering},
};

use alloc::boxed::Box;
use windows_sys::Win32::System::Memory::PAGE_READWRITE;

use crate::{
    allocator::NtHeapAlloc,
    api::{kernel32::Kernel32, ntdll::Ntdll, ws232::Ws232}, consts::{data_offset, CURRENT_PROCESS}, rip::{rip_end, rip_start},
};

pub struct Instance {
    pub base: *mut c_void,
    pub base_len: usize,
    pub heap_handle: *mut c_void,
    pub kernel32: Kernel32,
    pub ntdll: Ntdll,
    pub ws232: Ws232,
}

impl Instance {
    pub fn new() -> Self {
        let ntdll = Ntdll::new();
        let ws232 = Ws232::new(&ntdll);
        let kernel32 = Kernel32::new();

        Self {
            base: null_mut(),
            base_len: 0,
            heap_handle: null_mut(),
            kernel32,
            ntdll,
            ws232,
        }
    }

    pub unsafe fn setup(allocator: &NtHeapAlloc) {
        let mut local = Instance::new();

        local.base = rip_start();
        let end = unsafe { rip_end() };
        local.base_len = (end as usize) - local.base as usize;

        let offset = data_offset();
        let mut ptr = local.base.cast::<u8>().wrapping_add(offset) as _;
        let mut size = core::mem::size_of_val(&INSTANCE);
        let mut protect = 0x0;

        unsafe { (local.ntdll.nt_protect_virtual_memory)(
            CURRENT_PROCESS,
            &mut ptr,
            &mut size,
            PAGE_READWRITE,
            &mut protect,
        ) };

        let local_addr = &raw mut local;
        INSTANCE.store(local_addr, Ordering::Release);
        allocator.init();
        let local_heap = Box::into_raw(Box::new(local));
        INSTANCE.store(local_heap, Ordering::Release);
    }

    pub fn get() -> Option<&'static mut Self> {
        let ptr = INSTANCE.load(Ordering::Acquire);

        if ptr.is_null() {
            return None;
        }

        unsafe { Some(&mut *ptr) }
    }
}

#[unsafe(no_mangle)]
pub(crate) static INSTANCE: AtomicPtr<Instance> = AtomicPtr::new(core::ptr::null_mut());
