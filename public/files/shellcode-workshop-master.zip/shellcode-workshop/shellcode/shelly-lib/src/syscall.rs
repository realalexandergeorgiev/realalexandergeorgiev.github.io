use core::{arch::global_asm, ffi::c_void};

use crate::{info_addr, info_int, info_str};

unsafe extern "C" {
    pub fn make_syscall(ssn: u16, syscall_addr: usize, argc: u32, ...) -> i32;
}

// https://github.com/janoglezcampos/rust_syscalls/blob/main/src/syscall.rs
global_asm!(include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/src/syscall.s"
)));

pub fn dump_syscall_number_and_addr(func_ptr: *mut c_void) -> Result<(u32, usize), ()> {
    // TASK: Implement the syscall dumper
    //
    // HINT: Use the debugger to determine the required bytes to identify syscalls

    // TODO: REMOVE
    //
    if true {
        return Err(());
    }

    // 1. Find the bytes

    let mut instructions = [0u8; 400];

    // 2. Identify the syscall number

    let syscall_number = todo!();

    // 3. Identify the offset of the needed instruction

    let syscall_offset = todo!();

    let syscall_instr = unsafe { func_ptr.byte_add(syscall_offset).addr() };

    Ok((syscall_number, syscall_instr))
}
