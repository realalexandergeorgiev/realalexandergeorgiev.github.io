use core::{arch::asm, ffi::c_void, usize};

use windows_sys::Win32::System::{
    Diagnostics::Debug::{IMAGE_DATA_DIRECTORY, IMAGE_DIRECTORY_ENTRY_EXPORT, IMAGE_NT_HEADERS64},
    Kernel::LIST_ENTRY,
    SystemServices::{
        IMAGE_DOS_HEADER, IMAGE_DOS_SIGNATURE, IMAGE_EXPORT_DIRECTORY, IMAGE_NT_SIGNATURE,
    },
    WindowsProgramming::LDR_DATA_TABLE_ENTRY,
};

use crate::nocrt::{self, strlen, strlen16};

pub fn peb() -> *mut windows_sys::Win32::System::Threading::PEB {
    let ptr: *mut windows_sys::Win32::System::Threading::PEB;
    unsafe {
        asm!(
            "mov {}, gs:[0x60]",
            out(reg) ptr
        );
    }
    ptr
}

pub fn get_module_handle(name: &[u16]) -> Option<*mut c_void> {
    let peb = peb();

    // TASK: Lets find a way to find the module handle
    // https://github.com/winsiderss/systeminformer/blob/8ae6b7694f431743447662962e19e33205ad5e2f/phnt/include/ntldr.h#L212

    unsafe {
        let ldr_data = (*peb).Ldr;

        let entry = (*ldr_data).InMemoryOrderModuleList;

        // https://github.com/winsiderss/systeminformer/blob/8ae6b7694f431743447662962e19e33205ad5e2f/phnt/include/ntldr.h#L212
        let mut module_list = entry.Flink as *mut LDR_DATA_TABLE_ENTRY;

        while !module_list.is_null() {
            let dll_name_buffer = (*module_list).FullDllName.Buffer;
            let dll_name_len = (*module_list).FullDllName.Length as usize;

            let name_len = strlen16(dll_name_buffer).min(dll_name_len);
            let dll_name = core::slice::from_raw_parts(dll_name_buffer, name_len);

            if dll_name
                .iter()
                .zip(name)
                .all(|(a, b)| (*a as u8).eq_ignore_ascii_case(&(*b as u8)))
            {
                // TASK: Find the correct offset
                return (*module_list).Reserved2[0].into();
            }

            let cursor = module_list as *mut LIST_ENTRY;
            module_list = (*cursor).Flink as *mut LDR_DATA_TABLE_ENTRY;
        }
    }

    None
}

pub fn get_proc_addr(
    module_base_addr: *mut c_void,
    function_name: &[u8],
) -> Result<*mut c_void, ()> {
    unsafe {
        let image_export_directory = image_export_directory(module_base_addr)?;

        let number_of_functions = (*image_export_directory).NumberOfFunctions;

        let address_of_names =
            module_base_addr.add((*image_export_directory).AddressOfNames as usize);

        let names =
            core::slice::from_raw_parts_mut(address_of_names as *mut u32, number_of_functions as _);

        let function_addresses = core::slice::from_raw_parts(
            module_base_addr.add((*image_export_directory).AddressOfFunctions as usize)
                as *const u32,
            number_of_functions as _,
        );

        let function_ordinals_addresses = core::slice::from_raw_parts(
            module_base_addr.add((*image_export_directory).AddressOfNameOrdinals as usize)
                as *const u16,
            number_of_functions as _,
        );

        for i in 0..number_of_functions {
            let name_offset = names[i as usize] as usize;
            let name_addr = module_base_addr.add(name_offset) as *const i8;

            let len = nocrt::strlen(name_addr);
            let current_function_name = core::slice::from_raw_parts(name_addr.cast::<u8>(), len);

            if current_function_name == function_name {
                let ordinal = function_ordinals_addresses[i as usize] as usize;
                let func_ptr = module_base_addr.add(function_addresses[ordinal] as usize);
                return Ok(func_ptr);
            }
        }

    }
    Err(())
}

const fn dos_header(module_base_addr: *mut c_void) -> Result<*mut IMAGE_DOS_HEADER, ()> {
    let dos_header = module_base_addr as *mut IMAGE_DOS_HEADER;

    if (unsafe { *dos_header }).e_magic != IMAGE_DOS_SIGNATURE {
        return Err(());
    }

    Ok(dos_header)
}

const fn nt_header(module_base_addr: *mut c_void) -> Result<*mut IMAGE_NT_HEADERS64, ()> {
    let Ok(dos_header) = dos_header(module_base_addr) else {
        return Err(());
    };

    unsafe {
        let nt_headers = module_base_addr
            .add((*dos_header).e_lfanew as _)
            .cast::<IMAGE_NT_HEADERS64>();

        if (*nt_headers).Signature != IMAGE_NT_SIGNATURE {
            return Err(());
        }

        Ok(nt_headers)
    }
}

pub const fn image_export_directory(
    module_base_addr: *mut c_void,
) -> Result<*mut IMAGE_EXPORT_DIRECTORY, ()> {
    let Ok(nt_header) = nt_header(module_base_addr) else {
        return Err(());
    };

    let export_dir = unsafe {
        (*nt_header).OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT as usize]
            as IMAGE_DATA_DIRECTORY
    };

    let image_export_directory =
        unsafe { module_base_addr.byte_add(export_dir.VirtualAddress as usize) }
            as *mut IMAGE_EXPORT_DIRECTORY;

    Ok(image_export_directory)
}

#[inline]
pub fn get_current_process_id() -> u32 {
    #[unsafe(naked)]
    #[unsafe(link_section = ".text")]
    unsafe extern "C" fn get_current_process_id_inner() -> u32 {
        core::arch::naked_asm!("mov rax, gs:[0x30]", "mov eax, [rax+0x40]", "ret")
    }

    unsafe { get_current_process_id_inner() }
}
