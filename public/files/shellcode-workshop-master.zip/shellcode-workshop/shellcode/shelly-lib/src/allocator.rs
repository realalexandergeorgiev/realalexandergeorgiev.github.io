use core::{
    alloc::GlobalAlloc,
    ffi::c_void,
    ptr::{null, null_mut},
};

use windows_sys::Win32::{
    Foundation::INPLACE_S_TRUNCATED,
    System::Memory::{HEAP_GROWABLE, HEAP_NONE, HEAP_ZERO_MEMORY},
};

use crate::instance::Instance;

pub struct NtHeapAlloc;

impl NtHeapAlloc {
    pub const fn new() -> Self {
        Self
    }

    pub fn init(&self) {
        let Some(instance) = Instance::get() else {
            return;
        };

        let handle = unsafe {
            (instance.ntdll.rtl_create_heap)(HEAP_GROWABLE, null_mut(), 0, 0, null_mut(), null())
        };

        instance.heap_handle = handle;
    }
}

unsafe impl GlobalAlloc for NtHeapAlloc {
    unsafe fn alloc(&self, layout: core::alloc::Layout) -> *mut u8 {
        let Some(instance) = Instance::get() else {
            return core::ptr::null_mut();
        };

        // TASK: Add implement alloc

        instance
            .ntdll
            .call_RtlAllocateHeap(instance.heap_handle, HEAP_ZERO_MEMORY, layout.size())
            as _
    }

    unsafe fn dealloc(&self, ptr: *mut u8, _layout: core::alloc::Layout) {
        let Some(instance) = Instance::get() else {
            return;
        };

        instance
            .ntdll
            .call_RtlFreeHeap(instance.heap_handle, 0, ptr as _);
    }

    unsafe fn alloc_zeroed(&self, layout: core::alloc::Layout) -> *mut u8 {
        let Some(instance) = Instance::get() else {
            return core::ptr::null_mut();
        };
        // TASK: implement alloc_zeroed

        instance
            .ntdll
            .call_RtlAllocateHeap(instance.heap_handle, HEAP_ZERO_MEMORY, layout.size())
            as _
    }

    unsafe fn realloc(
        &self,
        ptr: *mut u8,
        _layout: core::alloc::Layout,
        new_size: usize,
    ) -> *mut u8 {
        let Some(instance) = Instance::get() else {
            return core::ptr::null_mut();
        };

        // TASK: implement realloc

        instance.ntdll.call_RtlReAllocateHeap(
            instance.heap_handle,
            0,
            ptr as *mut c_void,
            new_size as _,
        ) as _
    }
}
