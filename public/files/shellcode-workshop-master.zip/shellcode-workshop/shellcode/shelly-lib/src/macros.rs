use core::ptr::null_mut;

use alloc::vec::Vec;

use crate::{consts::STDOUT_HANDLE, instance::Instance};

pub fn print_str(s: &str) {
    if let Some(instance) = Instance::get() {
        let buf = s.bytes().chain([0].into_iter()).collect::<Vec<u8>>();
        let mut bytes_written: u32 = 0;
        unsafe {
            (instance.kernel32.write_file)(
                STDOUT_HANDLE,
                buf.as_ptr() as *const _,
                s.len() as _,
                &mut bytes_written,
                null_mut(),
            )
        };
    }
}

pub fn usize_to_hex_str(num: usize) -> [u8; 18] {
    // Lifted from stardust-rs
    let mut buffer = [b'0'; 16];
    let mut value = num;
    let mut index = 15;

    while value > 0 {
        let digit = value % 16;
        buffer[index] = match digit {
            0..=9 => b'0' + digit as u8,
            _ => b'a' + (digit - 10) as u8,
        };
        value /= 16;
        index -= 1;
    }

    let start_index = index + 1;

    let mut result = [0u8; 18];
    result[0] = b'0';
    result[1] = b'x';
    result[2..(16 + 2 - start_index)].copy_from_slice(&buffer[start_index..16]);

    result
}

pub fn usize_to_int_str(num: usize) -> [u8; 20] {
    let mut buffer = [b'0'; 20]; // Buffer to hold the integer characters
    let mut value = num;
    let mut index = 19;

    if value == 0 {
        buffer[index] = b'0';
        return buffer;
    }

    while value > 0 {
        let digit = value % 10;
        buffer[index] = b'0' + digit as u8;
        value /= 10;
        index -= 1;
    }

    let start_index = index + 1;
    let mut result = [0u8; 20];
    result[..(20 - start_index)].copy_from_slice(&buffer[start_index..20]);

    result
}

#[macro_export]
macro_rules! info_str {
    ($s:expr) => {
        let s = concat!($s, "\n");
        $crate::macros::print_str(s);
    };
}

#[macro_export]
macro_rules! info_addr {
    ($name:expr, $addr:expr) => {
        let hex_buf = $crate::macros::usize_to_hex_str($addr as usize);
        #[allow(unused_unsafe)]
        let hex_str: &str = unsafe { core::str::from_utf8_unchecked(&hex_buf) };

        $crate::macros::print_str(concat!($name, ":\t"));
        $crate::macros::print_str(&hex_str);
        $crate::macros::print_str("\n");
    };
}

#[macro_export]
macro_rules! info_int {
    ($name:expr, $addr:expr) => {
        let int_buf = $crate::macros::usize_to_int_str($addr as usize);
        #[allow(unused_unsafe)]
        let int_str: &str = unsafe { core::str::from_utf8_unchecked(&int_buf) };

        $crate::macros::print_str(concat!($name, ":\t"));
        $crate::macros::print_str(&int_str);
        $crate::macros::print_str("\n");
    };
}
