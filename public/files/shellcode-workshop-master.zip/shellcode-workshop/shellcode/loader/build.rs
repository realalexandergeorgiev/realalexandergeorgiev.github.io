fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("cargo::rerun-if-changed=../shelly-lib/");
    println!("cargo::rerun-if-changed=../shelly/");


    
    // TASK: Add a simple base64 encoder to the loader by using the base64 crate.
    //       Use the implants directory for encoded shellcode
    //
    // Extra Challenge: Instead of base64, use the crypto crate ring to encrypt
    //                  the shellcode. The key and nonce can be passed to programm 
    //                  via `cargo::rustc-env=KEY=VALUE`.
    //
    //
    // LINKS:
    //  - https://crates.io/crates/base64
    //  - https://crates.io/crates/ring
    //
    // HINT: Use the base64 crate


    Ok(())
}
