#!/bin/bash

docker build --rm . -t compile
