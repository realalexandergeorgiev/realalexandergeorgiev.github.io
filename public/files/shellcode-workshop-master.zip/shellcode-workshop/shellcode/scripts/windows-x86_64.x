ENTRY(_start);

SECTIONS
{
    . = 0x0000;

    .text ALIGN(16) :
    {
        . = 0x0;
        *(.text.prologue)
        *(.text.implant)
        *(.text)
        *(.rodata*)
        *(.rdata*)

        FILL( 0x00 )
        . = ALIGN(0x1000);

        _data_offset = .;
        *(.data*)
        *(.bss*)
        _epilogue_offset = .;
        *(.text.epilogue)
    }

    /DISCARD/ :
    {
        *(.interp)
        *(.comment)
        /**/
        *(.idata*)
        *(.pdata*)
        *(.xdata*)
        /**/

        *(.debug_frame)
        *(.reloc)
    }
}
