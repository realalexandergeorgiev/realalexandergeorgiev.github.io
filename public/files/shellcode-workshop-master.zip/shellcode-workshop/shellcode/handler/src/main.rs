fn main() -> Result<(), Box<dyn std::error::Error>> {
    let addr = std::env::args().nth(1).ok_or("No addr provided")?;
    let file = std::env::args().nth(2).ok_or("No implant file provided")?;

    let implant_data = std::fs::read(file)?;

    // TASK 1: Create a simple tcp handler. The handler should create a handle thread for each
    // incoming connection.
    //
    // LINK:
    //  - https://doc.rust-lang.org/std/net/struct.TcpListener.html
    //  - https://crates.io/crates/ring

    Ok(())
}
