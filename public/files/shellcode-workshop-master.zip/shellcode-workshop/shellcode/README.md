# Shelly - Bsides FFM Shellcode Template


## Getting started


### Setting up docker

```
./setup-docker.sh
```



### Building

```
./x cargo make --profile x86_64-windows
```


### Cleaning 


```
./x cargo make --profile x86_64-windows clean
```


