use heck::{ToSnakeCase, ToUpperCamelCase};
use proc_macro::{TokenStream};
use quote::{format_ident, quote, ToTokens};
use syn::{
    Item, ItemMod, ItemType, Meta, Token, Type, TypeBareFn, parse_macro_input,
    punctuated::Punctuated,
};

#[proc_macro_attribute]
pub fn syscall_impl(attr: TokenStream, item: TokenStream) -> TokenStream {
    let syscall_util_functions =
        parse_macro_input!(attr with Punctuated<Meta, Token![,]>::parse_terminated);
    let mut syscall_util_functions = syscall_util_functions.iter();
    let module_search_function = syscall_util_functions.next();
    let syscall_dumper = syscall_util_functions.next();
    let syscaller = syscall_util_functions.next();
    
    let struct_name = syscall_util_functions.next();

    let input = parse_macro_input!(item as ItemMod);

    let mod_ident = input.ident.clone();
    let syscall_struct = format_ident!("{}", input.ident.to_string().to_upper_camel_case());

    let mod_items = input.content.map(|i| i.1).unwrap();

    let (mod_ffi_decl, struct_members) = mod_items
        .iter()
        .filter(|item| {
            matches!(
                item,
                Item::Type(ItemType {
                    vis: syn::Visibility::Public(_),
                    ty,
                    ..
                })
                if matches!(**ty, Type::BareFn(_))
            )
        })
        .filter_map(|i| match i {
            Item::Type(i) if matches!(i, ItemType { .. }) => Some(i),
            _ => None,
        })
        .fold((Vec::new(), Vec::new()), |(mut acc, mut members), i| {
            let Type::BareFn(TypeBareFn {
                ref inputs,
                ref output,
                ..
            }) = *i.ty
            else {
                unreachable!()
            };

            let attrs = &i.attrs;
            let fn_name = i.ident.to_string();
            let fn_ident = &i.ident;

            let field_fn_ident = format_ident!("{}", i.ident.to_string().to_snake_case());
            
            let args = inputs.iter().flat_map(|j| j.name.as_ref().map(|i| {
                let ident = i.0.clone();
                match &j.ty {
                    Type::Path(type_path) if type_path.path.clone().into_token_stream().to_string() == "u16" => {
                        quote! { #ident as core::ffi::c_uint }
                    }
                    _ => {
                        quote! { #ident }
                    },
                }
        
            })).collect::<Vec<_>>();
            let argc = args.len();

            let build_fn = format_ident!("build_{}", fn_name);
            let call_fn = format_ident!("call_{}", fn_name);

            let fn_name_bytes = fn_name.as_bytes();

            members.push(quote! {
                pub #field_fn_ident: #fn_ident,
            
            });

            acc.push(quote! {
                #(#attrs)*
                #[allow(non_snake_case)]
                pub fn #build_fn(base: *mut core::ffi::c_void) -> #fn_ident {
                    unsafe{
                        let Ok(func) = #module_search_function(base, &[#(#fn_name_bytes),*]) else { 
                            return core::mem::transmute(core::ptr::null_mut::<core::ffi::c_void>()); 
                        };

                        core::mem::transmute(func)
                    }
                }

                #(#attrs)*
                #[allow(non_snake_case)]
                pub fn #call_fn(&self, #inputs) #output {
                    let res = unsafe { #syscall_dumper(self.#field_fn_ident as *mut core::ffi::c_void) };
                    match res {
                        Ok((ssn, addr)) => unsafe { #syscaller(ssn as _, addr, #argc as _, #(#args),*) as _ },
                        Err(_) => {
                            unsafe { (self.#field_fn_ident)(#(#args as _),*) as _  }
                        }
                    }
                }
            });
            (acc, members)
        });

    let expanded = quote! {
        pub mod #mod_ident {
            #(#mod_items)*
            
            pub struct #struct_name {
                #(#struct_members)*
            }

            impl #syscall_struct {
                #(#mod_ffi_decl)*
            }
        }
    };

    expanded.into()
}
